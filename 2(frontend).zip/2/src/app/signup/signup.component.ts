import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { MyUser } from '../my-user';
import { UserService } from '../user.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  signupForm:any;
  signStatus:any;
  users:any;

  constructor(private fb:FormBuilder, private us:UserService) { 
    this.signupForm=this.fb.group({
      username:[],
      password:[],
      confirmPassword:[]
    });
  }

  ngOnInit(): void {
    this.us.getAllUsers().subscribe((data)=>{
      console.log(data);
      this.users=data;                                  
     })
  }

  signup()
  {
    this.signStatus = true;
    var myuser=new MyUser();
    myuser.username=this.signupForm.controls['username'].value;
    myuser.password=this.signupForm.controls['password'].value;
    myuser.role="user";
    
                                                                          // alert(JSON.stringify(myuser));
    this.us.signup(myuser).subscribe(data=>console.log(data));
    // this.us.dummy().subscribe(data=>console.log(data));
  }

}
