import { JsonpClientBackend } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { MovieServiceService } from '../movie-service.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  adminMovieForm:any;
 /*  file : any; */
  movies:any;
  constructor(private fb: FormBuilder, private ms: MovieServiceService) { 
    this.adminMovieForm=this.fb.group({
      id:[''],
      movieName:[''],
      theatre:['']
  /*     picture:[''] */
    });
  }
  ngOnInit(): void {
                                                                         // alert("init method");
    this.ms.getAllMovie().subscribe((data)=>{
      console.log(data);
      this.movies=data;                                  
     })  
                                                                        //  alert(JSON.stringify(this.movies));
  }
   
  


  // fnAdd()
  // {
    // var fd=new FormData();                                                      // we will append each data in formdata whenever user enter details, At last we supply formdata obj BY calling service method
    // alert(this.foodForm.controls['expiryDate'].value);
    // fd.append("id",this.adminMovieForm.controls['id'].value);
    // fd.append("movieName",this.adminMovieForm.controls['movieName'].value);
    // fd.append("theatre",this.adminMovieForm.controls['theatre'].value);
  /*   fd.append("picture",this.file,this.file.name); */

    // this.ms.addMovie(fd).subscribe(data=>console.log(data));                     // entered data in html form will store in database by calling " Movie servie " method
                                                                           // alert("Form details submitted")
  // }

}
