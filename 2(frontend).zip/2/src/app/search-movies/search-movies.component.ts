import { Component, OnInit } from '@angular/core';
import { MovieService } from '../movie.service';

@Component({
  selector: 'app-search-movies',
  templateUrl: './search-movies.component.html',
  styleUrls: ['./search-movies.component.css']
})
export class SearchMoviesComponent implements OnInit {
  movies:any;
  name:any;
  status:any;
  constructor(private ms: MovieService) { }
   
  ngOnInit(): void {
    this.ms.getMovieById(localStorage.getItem("search")).subscribe((data)=>{
      console.log(data);
      this.movies=data; 
      console.log(this.movies);                                 
     })
    alert("cmaksdcf " + localStorage.getItem("search"));

  }

  fnSearchBook(){
  //   alert("Please Login to book the movie")
  // this.name= "Please Login to book the movie";
  this.status=true;
  }

}
