import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-no-tickets',
  templateUrl: './no-tickets.component.html',
  styleUrls: ['./no-tickets.component.css']
})
export class NoTicketsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
