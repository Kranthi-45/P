export class MyUser {
    
    username:string | undefined;
    password:string | undefined;
    role:string | undefined;
}
