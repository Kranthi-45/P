import { JsonpClientBackend } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Book } from '../book';
import { PayBookService } from '../pay-book.service';

@Component({
  selector: 'app-invoice',
  templateUrl: './invoice.component.html',
  styleUrls: ['./invoice.component.css']
})
export class InvoiceComponent implements OnInit {
  
  book: Book = new Book;
  bookimage:any;
  constructor( private ps: PayBookService ) { }

  ngOnInit(): void {
    this.book = this.ps.fnBook();
    //  var book1 = localStorage.getItem("confirmBook");
    //  if(book1!==null){
    //  var book = JSON.parse(book1);
    //  }
                                                                       // alert(JSON.stringify(this.book))
    this.bookimage=localStorage.getItem("bookimage");
    // alert(this.bookimage);  
  }

}
