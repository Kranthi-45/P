import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { ManageUsersService } from '../manage-users.service';
import { MyUser } from '../my-user';

@Component({
  selector: 'app-manage-users',
  templateUrl: './manage-users.component.html',
  styleUrls: ['./manage-users.component.css']
})
export class ManageUsersComponent implements OnInit {

  userForm:any;
  constructor(private fb:FormBuilder, private mus: ManageUsersService ) {
    this.userForm=this.fb.group({
      // userId:[''],
      userName:[''],
      password:[''],
      role:['']
    });
   }

  ngOnInit(): void {
  }

  fnAdd(){
    var muser=new MyUser();

    // muser.userI=this.userForm.controls['userId'].value;
    muser.username=this.userForm.controls['userName'].value;
    muser.password=this.userForm.controls['password'].value;
    muser.role=this.userForm.controls['role'].value;

    // alert("fn ADD " +JSON.stringify(movie));
    this.mus.addUser(muser).subscribe(data=>console.log(data));
  }

  fnModify(){
    var muser=new MyUser();

    // muser.userI=this.userForm.controls['userId'].value;
    muser.username=this.userForm.controls['userName'].value;
    muser.password=this.userForm.controls['password'].value;
    muser.role=this.userForm.controls['role'].value;

    this.mus.modifyUser(muser).subscribe(data=>console.log(data));
  }

  fnDelete(){
    var muser=new MyUser();

    // muser.userI=this.userForm.controls['userId'].value;
    muser.username=this.userForm.controls['userName'].value;
    // muser.password=this.userForm.controls['password'].value;
    // muser.role=this.userForm.controls['role'].value;

    this.mus.removeUser(muser.username).subscribe(data=>console.log(data));
  }
}
