import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { Book } from '../book';
import { BookService } from '../book.service';
import { Movie } from '../movie';
import { MovieService } from '../movie.service';
import { PayBookService } from '../pay-book.service';
import { PaymentBookComponent } from '../payment-book/payment-book.component';

@Component({
  selector: 'app-book',
  templateUrl: './book.component.html',
  styleUrls: ['./book.component.css']
})
export class BookComponent implements OnInit {

  movies:any;
  movieById:any;
  movieForm:any;
  book: Book = new Book();
  DisplayTickets:any;
  bookedimage:any;                        // added
  constructor(private fb:FormBuilder, private ms: MovieService, private bs:BookService, private router:Router, private ps: PayBookService) {
    this.movieForm=this.fb.group({
      movieId:[''],
      movieName:[''],
      theatreId:[''],
      tickets:[''],
      category:['']
    });
   }

  ngOnInit(): void {
    this.ms.getAllMovie().subscribe((data)=>{
      console.log(data);
      this.movies=data;                                  
     });
  }
   
  fnBook(mov:any){
   // alert("Entering into Book fn " + JSON.stringify(mov));
    if(localStorage.getItem('user')==null)
    {
      console.log("NOt logged in.")
      return;
    }
    var str=localStorage.getItem('user');
    if(str!=null){
      var user=JSON.parse(str);
  //    alert(" user object " + JSON.stringify(str));
      var customer_id=user.userId;
        // var book = new Book();                        // real
        //  book.bookDate=new Date();
        //  book.theatreId=mov.theatreId;
        //  book.movieId=mov.movieId;
        //  book.customerId=customer_id;

         this.book.bookDate=new Date();
         this.book.theatreId=mov.theatreId;
         this.book.movieId=mov.movieId;
         this.book.customerId=customer_id;

         //var book1 = new Book;

         
        // this.router.navigate(['/seats'])                                  
        // this.bs.bookTicket(book).subscribe(data=>console.log(data));                 // real
      
      this.ms.getMovieById(this.book.movieId).subscribe((data)=>{
      this.movieForm.patchValue(data);                       
      });

      this.ms.getMovieById(this.book.movieId).subscribe((data)=>{
        console.log(data);
        this.movieById=data; 
        this.bookedimage=this.movieById.image;                                                      // added
        localStorage.setItem("bookimage", this.bookedimage);                                           // added
        // alert(JSON.stringify(this.bookedimage));
        var availableTickets = this.movieById.noOfTickets;
        this.DisplayTickets = availableTickets;
                                                                         // alert(" display tickets  " + this.DisplayTickets);

      });
     

      // this.ms.getMovieById(mov.movieId).subscribe((data)=>{
      //   console.log(data);
      //   this.movieById=data;                                  
      //  });
      //  var enteredTickets = this.movieForm.controls['noOfTickets'].value;
      //  var availableTickets = this.movieById.noOfTickets;
      //  if(enteredTickets <=  availableTickets ){
      //    availableTickets= availableTickets-enteredTickets;
      //  }else{
      //    alert("Tickets are not available");
      //    return;
      //  }
     
    
       
                                                                             //  alert(JSON.stringify(" book " + this.book))
       localStorage.setItem("confirmBook", JSON.stringify(this.book));
       console.log(this.book);

      //   this.ps.bookTicket(this.book);                                                       // real navigation   
     //this.router.navigate(['/payBook']);
   }
                                                                              // alert(str);
  }

  fnAdd(){
    
    this.book.tickets =  this.movieForm.controls['tickets'].value;
    this.book.seatType = this.movieForm.controls['category'].value;

    this.ms.getMovieById(this.book.movieId).subscribe((data)=>{
      console.log(data);
      this.movieById=data; 
                                                                        // alert(JSON.stringify(this.movieById)); 

      var availableTickets = this.movieById.noOfTickets;
      this.DisplayTickets = availableTickets;
                                                                         // alert(" FSDG  " + availableTickets);
                                                                         // alert(" display tickets  " + this.DisplayTickets);

      var enteredTickets = this.book.tickets;

      if(enteredTickets==0){
                                                                          // alert(" Entered tickets should not be 0");
        this.router.navigate(['/noTickets']);
      }
      
      if(enteredTickets <= availableTickets){
        availableTickets = availableTickets - enteredTickets;
                                                                             // alert(availableTickets);
        this.movieById.noOfTickets=availableTickets;
       this.ms.modifyMovie(this.movieById).subscribe(data=>console.log(data));
       this.router.navigate(['/payBook']);
      }else{
        this.router.navigate(['/noTickets']);
      }

     });

                                                                       //  alert(JSON.stringify(" book object to local storage " + this.book))
     localStorage.setItem("confirmBook", JSON.stringify(this.book));
     console.log(this.book);
    
                                                                        // alert("before booking, id " + JSON.stringify(this.book));
   this.bs.bookTicket(this.book).subscribe(data=>console.log(data)); 
   this.ps.bookTicket(this.book);  
   //this.router.navigate(['/payBook']);
  }



  // fnBook(mov:any){
  //   alert(JSON.stringify(mov));
  //   if(localStorage.getItem('user')==null)
  //   {
  //     console.log("NOt logged in.")
  //     return;
  //   }
  //   var str=localStorage.getItem('user');
  //   if(str!=null){
  //     var user=JSON.parse(str);
  //     alert(JSON.stringify(str));
  //     var customer_id=user.userId;
  //     var book = new Book(); 
  //        book.bookDate=new Date();
  //        book.theatreId=mov.theatreId;
  //        book.movieId=mov.movieId;
  //        book.customerId=customer_id;
  //        book.tickets=1;
  //        alert(JSON.stringify(book))
  //        localStorage.setItem("confirmBook", JSON.stringify(book));
  //        console.log(book);

  //        this.router.navigate(['/seats'])
  //                                                                         //   this.ps.payBook(book);
  //     // this.bs.bookTicket(book).subscribe(data=>console.log(data));
  //     this.bs.bookTicket(book).subscribe(data=>console.log(data));

      
  //     this.ms.getMovieById(book.movieId).subscribe((data)=>{
  //     this.movieForm.patchValue(data);                       
  //     });
  //     this.ps.bookTicket(book);
  //     //this.router.navigate(['/payBook']);
  //  }
  //   alert(str);
  //   // var customer_id=customer.id;
  // }
  
  fnDelete(){}


//   fnBuy(id)
//   {
//     alert(id);
//     if(localStorage.getItem('customer')==null)
//     {
//       console.log("NOt logged in.")
//       return;
//     }
//     var str=localStorage.getItem('customer');
//     var customer=JSON.parse(str);
//     var customer_id=customer.id;
//     var order=new Order();
//     order.orderDate=new Date();
//     order.productId=id;
//     order.customerId=customer_id;
//     order.quantity=1;
//     console.log("Going to place an order as below");
//     console.log(order);
//     this.os.placeOrder(order).subscribe(data=>console.log(data));
//  }



}
function subscribe(arg0: (data: any) => void) {
  throw new Error('Function not implemented.');
}

