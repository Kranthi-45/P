
export class Movie {
    movieId:number | undefined;
    movieName:string | undefined;
    noOfTickets:number | undefined;
    theatreId:number| undefined;
}
