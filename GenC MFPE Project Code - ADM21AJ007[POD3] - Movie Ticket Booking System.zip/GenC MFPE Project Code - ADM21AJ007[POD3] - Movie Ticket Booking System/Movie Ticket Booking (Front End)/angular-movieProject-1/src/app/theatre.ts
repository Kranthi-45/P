export class Theatre {
    theatreId:number | undefined;
    theatreName:string | undefined;
    // movieList: any[] | undefined;
}
