package com.example.demo.dao;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.example.demo.mappers.BookRowMapper;
import com.example.demo.model.Book;

@Component
public class BookDaoImpl implements BookDao  {
	@Autowired
	private JdbcTemplate jdbcTemplate;
	

	@Override
	public int create(Book book) {
		return jdbcTemplate.update("INSERT INTO booking VALUES (?,?,?,?,?,?,?)", book.getId(), book.getBookDate(), book.getTheatreId(), book.getMovieId(),book.getCustomerId(), book.getTickets(), book.getSeatType());
	}
	
	public Long generateBookId() {
		 
		List<Book> n = jdbcTemplate.query("SELECT * FROM booking b where b.id IN ( select max(id) from  booking ) order by id desc", new BookRowMapper());;
		Book lastbook = n.get(0);
		Long max  = lastbook.getId();
		Long genId=1L;
		if(max==0L) {
			genId=1L;
		}else {
			genId=max + 1L;
		}
		
		return genId;
	}
	
	
	@Override
	public List<Book> read() {
		return jdbcTemplate.query("SELECT * FROM booking", new BookRowMapper());
	}
	
	
	@Override
	public Book read(Long id) {
		return jdbcTemplate.queryForObject("SELECT * FROM booking WHERE id=?", new BookRowMapper(), id);
	}
	
	@Override
	public List<Book> findBooksByCustomer(Long customer_id)
	{
		return jdbcTemplate.query("SELECT * FROM booking WHERE customer_id=?", new BookRowMapper(), customer_id);
	}
	
	
	
	@Override
	public int update(Book book) {
		return jdbcTemplate.update("UPDATE booking SET bookingDate=?, theatre_id=?, movie_id=?, customer_id, tickets WHERE id=?", book.getBookDate(), book.getTheatreId(), book.getMovieId(),book.getCustomerId(), book.getTickets(), book.getId());
	}
	
	
	
	@Override
	public int delete(Long id) {
		return jdbcTemplate.update("DELETE FROM booking WHERE id=?",id);
	}
	
}
