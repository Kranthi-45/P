package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Movie;
import com.example.demo.model.MyUser;
import com.example.demo.service.MyUserDetailsService;

@RestController
@CrossOrigin(origins = {"http://localhost:4200","*"}, allowedHeaders = "*")

public class UserController {

	@Autowired
	private MyUserDetailsService ms;
	
	@GetMapping("/")
	public String home()
	{
		return "Hello world";
	}
	
	@GetMapping("/user")
	public List<MyUser> getAllUsers()
	{
		return ms.read();
	}
	
	@PostMapping("/user")
	public int signup(@RequestBody MyUser user)
	{
		System.out.println("What i have received: "+user);
		return ms.create(user);
	}
	
	@PutMapping("/user")
	public int modifyUser(@RequestBody MyUser user)
	{
		System.out.println("entering modify method "+ user);

		return ms.modifyUser(user);
	}
	
	@DeleteMapping("/user/{username}")
	public int deleteUser(@PathVariable("username") String username)
	{
		System.out.println("entering delete method "+ username);
		return ms.deleteUser(username);
	}
	
	
	@GetMapping("/user/{username}/{password}/{role}")
	public MyUser login(@PathVariable String username, @PathVariable String password,@PathVariable String role )
	{
		MyUser user = ms.read(username);
		if(user.getPassword().equals(password))
			return user;
		return null;
	}
	
//	@GetMapping("/user/{username}/{password}")
//	public MyUser login(@PathVariable String username, @PathVariable String password)
//	{
//		MyUser user = ms.read(username);
//		if(user.getPassword().equals(password))
//			return user;
//		return null;
//	}
}
