package com.example.demo.model;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Set;


public class Movie {
	
	private Long movieId;
	private String movieName;
//	private Date releaseDate;
//  private List theatreList;
	private Long theatreId;
	private Long noOfTickets;
	private byte[] image;                                                                  // added here & add new colom of type LONGBLOB in db                       
	public Movie() {
		//theatreList = new ArrayList();
	}
	
//	public Movie(Long movieId, String movieName, Long theatreId) {
//		super();
//		this.movieId = movieId;
//		this.movieName = movieName;
//	//	this.theatreList = theatreList;
//		this.theatreId = theatreId;
//	}
	
	

//	public Movie(Long movieId, String movieName, Long theatreId, Long noOfTickets) {         // previous
//	super();
//	this.movieId = movieId;
//	this.movieName = movieName;
//	this.theatreId = theatreId;
//	this.noOfTickets = noOfTickets;
//    }

	public Movie(Long movieId, String movieName, Long theatreId, Long noOfTickets, byte[] image) {        // added
		super();
		this.movieId = movieId;
		this.movieName = movieName;
		this.theatreId = theatreId;
		this.noOfTickets = noOfTickets;
		this.image = image;
	}

	
	public byte[] getImage() {                       // added
		return image;
	}

	public void setImage(byte[] image) {             // added  
		this.image = image;
	}

	public Long getMovieId() {
		return movieId;
	}

	
	public void setMovieId(Long movieId) {
		this.movieId = movieId;
	}

	public String getMovieName() {
		return movieName;
	}

	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}

	public Long getTheatreId() {
		return theatreId;
	}

	public void setTheatreId(Long theatreId) {
		this.theatreId = theatreId;
	}

	public Long getNoOfTickets() {
		return noOfTickets;
	}

	public void setNoOfTickets(Long noOfTickets) {
		this.noOfTickets = noOfTickets;
	}
 
	@Override                                                                 // added  next rowmapper
	public String toString() {                           
		return "Movie [movieId=" + movieId + ", movieName=" + movieName + ", theatreId=" + theatreId + ", noOfTickets="
				+ noOfTickets + ", image=" + Arrays.toString(image) + "]";
	}

	


//	public List getTheatreList() {
//		return theatreList;
//	}
//
//	public void setTheatreList(List theatreList) {
//		this.theatreList = theatreList;
//	}
	

	
}
