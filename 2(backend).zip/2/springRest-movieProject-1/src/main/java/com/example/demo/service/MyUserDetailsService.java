package com.example.demo.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.example.demo.mappers.MyUserRowMapper;
import com.example.demo.model.MyUser;


@Service
public class MyUserDetailsService {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	public int create(MyUser user) {
		String sql="INSERT INTO MyUser VALUES(?,?,?,?)";
		return jdbcTemplate.update(sql, user.getUserId(), user.getUsername(), user.getPassword(), "user");
	}
	public List<MyUser> read() {
		return jdbcTemplate.query("SELECT * FROM MyUser", new MyUserRowMapper());
	}
	public MyUser read(String username) {
		return jdbcTemplate.queryForObject("SELECT * FROM MyUser WHERE username=?", new MyUserRowMapper(), username);
	}
	public int update(MyUser user) {
		String sql="UPDATE MyUser SET username=?, password=? WHERE userId=?";
		return jdbcTemplate.update(sql, user.getUsername(), user.getPassword(), user.getUserId());
	}
	public int delete(Long userId) {
		String sql="DELETE FROM MyUser WHERE userId=?";
		return jdbcTemplate.update(sql, userId);
	}
	public int modifyUser(MyUser user) {
		String sql="UPDATE MyUser SET password=?, role=? WHERE username=? ";
		return jdbcTemplate.update(sql, user.getPassword(), user.getRole(), user.getUsername());
	}
	
	public int deleteUser(String username) {
		String sql="DELETE FROM MyUser WHERE username=?";
		return jdbcTemplate.update(sql, username);
   
	}

}
